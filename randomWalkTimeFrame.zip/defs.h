#pragma once

#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <time.h>
#include <chrono>
#include <ctime>
#include <vector>
#include <unordered_map>
#include <queue>
#include <bitset>
#include <functional>	// std::greater; bind()
#include <random>		// uniform_real_distribution<>


#define EXE_DIR "C:/Users/Ronald/source/repos/randomWalkTimeFrame/x64/Release"
#define uint uint32_t
#define ushort uint16_t
#define real double
//#define real float
#define READ_NTWK_FROM_FILE
//#define SERIALIZE
//#define DE_SERIALIZE
#define COMMENTARY '#'
#define GENERATE_NETWORK
#define CLIQUE

//#define NTWK_SIZE 55
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\grafoDeTestes.txt"), 55
//#define NWTK_LABEL "Ronald"
//#define SHORT_LABEL "ron"

#define NTWK_SIZE 4039
#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\facebook_combined.txt"), 4039
#define NWTK_LABEL "Fb"
#define SHORT_LABEL "fb"

//#define NTWK_SIZE 12008
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\CA-HepPh.txt"), 12008
//#define NWTK_LABEL "HepPh"
//#define SHORT_LABEL "hep"

//#define NTWK_SIZE 15233
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\netHEPT.txt"), 15233
//#define NWTK_LABEL "net"
//#define SHORT_LABEL "net"

//#define NTWK_SIZE 18772
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\CA-AstroPh.txt"), 18772
//#define NWTK_LABEL "AstroPh"
//#define SHORT_LABEL "astro"

//#define NTWK_SIZE 23133
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\CA-CondMat.txt"), 23133
//#define NWTK_LABEL "CondMat"
//#define SHORT_LABEL "cmat"

//#define NTWK_SIZE 36692
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\Email-Enron.txt"), 36692
//#define NWTK_LABEL "Enron"
//#define SHORT_LABEL "enron"

//#define NTWK_SIZE 58228
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\Brightkite_edges.txt"), 58228
//#define NWTK_LABEL "Brightkite"
//#define SHORT_LABEL "bk"
 
//#define NTWK_SIZE 196591
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\Gowalla_edges.txt"), 196591
//#define NWTK_LABEL "Gowalla"
//#define SHORT_LABEL "gw"

//#define NTWK_SIZE 317080
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\com-dblp.ungraph.txt"), 317080
//#define NWTK_LABEL "dblp"
//#define SHORT_LABEL "dblp"

//#define NTWK_SIZE 334863
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\com-amazon.ungraph.txt"), 334863
//#define NWTK_LABEL "amazon"
//#define SHORT_LABEL "amz"

//#define NTWK_SIZE 1696415
//#define SOURCE_FILE string(string(EXE_DIR) + "\\redes\\as-skitter.txt"), 1696415
//#define NWTK_LABEL "as-skitter"
//#define SHORT_LABEL "as"